HOST = 'localhost'
FORMAT = 'utf-8'
ELECTION_WAIT = 10
VERBOSE = True